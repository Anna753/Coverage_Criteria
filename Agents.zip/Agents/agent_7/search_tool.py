from langchain_community.utilities import SerpAPIWrapper
from langchain_community.tools import Tool

search = SerpAPIWrapper()

search_tool = Tool(
    name = "google_search",
    func= search.run,
    description="Search the web using Google's API"
)