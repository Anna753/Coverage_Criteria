from langchain.agents import load_tools
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import OpenAI, ChatOpenAI
import os
import getpass
from langchain.memory import ConversationBufferMemory
from langchain.agents import initialize_agent, AgentType
from search_tool import search_tool
from math_tool import math_tool

class Agent():
    def __init__():
        pass
    def build_agent():

       
        llm = ChatOpenAI(
            model="google/gemini-2.5-pro",
            base_url="https://openrouter.ai/api/v1",
            temperature=0,api_key=os.environ["OPENROUTER_API_KEY"]
        )

        # ✅ Initialize memory
        memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

        # ✅ Define tools
        tools = [search_tool, math_tool]

        # ✅ Initialize the agent with correct LLM instance
        agent_executor = initialize_agent(
            tools=tools,
            llm=llm,  # ✅ Make sure this is an actual LLM instance
            agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True,
            memory=memory, handle_parsing_errors=True,
            return_intermediate_steps=True, max_iterations=20
        )

        return agent_executor, tools