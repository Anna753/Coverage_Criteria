from tool import crawls_google
from langchain_openai import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain_core.tools import Tool
from langchain.agents import create_react_agent, AgentExecutor
from langchain import hub
import os

class Agent():
    def __init__():
        pass
    def build_agent():

            llm = ChatOpenAI(temperature=0, model_name="gpt-4o")

            prompt_template = PromptTemplate(
                    template="""
                    Give me a list of 3 to 5 restaurants where I can have {meal_of_the_day}. 
                    Make sure the restaurants are in {city}.
                    Make sure the restaurants are {restaurant_type}.
                    {additional_info}
                    """,
                    input_variables=[
                        "meal_of_the_day",
                        "city",
                        "restaurant_type",
                        "additional_info",
                    ],
                )
            tools_for_agent = [
                    Tool(
                        name="Crawl google for restaurants",
                        func=crawls_google,
                        description="Useful when you need to find a restaurant in the city",
                    )
                ]
            react_prompt = hub.pull("hwchase17/react")
            agent = create_react_agent(llm=llm, tools=tools_for_agent, prompt=react_prompt)
            agent_executor = AgentExecutor(
                    agent=agent, tools=tools_for_agent, verbose=True, handle_parsing_errors=True, return_intermediate_steps=True,  max_iterations=20
                )
             
            return agent_executor, tools_for_agent