
from langchain_openai import OpenAI
import os
import getpass
from langchain.agents import initialize_agent, AgentType
from langchain.memory import ConversationBufferWindowMemory
from langchain_community.tools import YouTubeSearchTool
from langchain_community.llms import OpenAI
from langchain_community.tools import YouTubeSearchTool, WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

class Agent():
    def __init__():
        pass
    def build_agent():

    
        llm = OpenAI(temperature=0)
        
        # Manually define tools
        yt_tool = YouTubeSearchTool()
        wiki_tool = WikipediaQueryRun(api_wrapper=WikipediaAPIWrapper())

        tools = [yt_tool, wiki_tool]  # Manually specify tools

        # Initialize memory with a context window of 5 interactions
        memory = ConversationBufferWindowMemory(k=5, return_messages=True)

        # Initialize the multi-tool agent with memory
        agent = initialize_agent(
            tools=tools,  # Pass the tools list directly
            llm=llm,
            agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            memory=memory,
            verbose=True, handle_parsing_errors=True, return_intermediate_steps=True,  max_iterations=20 # Set to False to hide intermediate reasoning steps
        )

       
        return agent, tools