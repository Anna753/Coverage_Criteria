from langchain.agents import load_tools
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import OpenAI, ChatOpenAI
import os
import getpass
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
import os
from langchain.tools import tool

class Agent():
    def __init__():
        pass
    def build_agent():
        
        @tool
        def say_hello(name: str) -> str:
            """Says hello to the user."""
            return f"Hi {name}, nice to meet you!"

        @tool
        def calculate(expression: str) -> str:
            """Calculates the result of simple arithmetic expressions"""
            try:
                return str(eval(expression))
            except Exception as e:
                return f"Error: {e}"

        
        llm = ChatOpenAI(
            model="google/gemma-3-12b-it",
            base_url="https://openrouter.ai/api/v1",
            temperature=0,api_key=os.environ["OPENROUTER_API_KEY"]
        )
        
        tools = [calculate]
        agent = initialize_agent(
            tools=tools,  
            llm=llm,
            agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True,
            handle_parsing_errors=True, return_intermediate_steps=True,  max_iterations=10
        )

        return agent, tools