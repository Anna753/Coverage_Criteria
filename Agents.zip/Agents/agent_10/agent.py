
from langchain import hub
from langchain_openai import ChatOpenAI
from langchain_community.tools.tavily_search.tool import TavilySearchResults
from langchain.agents import (
    create_react_agent,
    AgentExecutor,
)

class Agent():
    def __init__():
        pass
    def build_agent():

        tools = [TavilySearchResults(max_results=5)]

    # prompt for the react agent
        prompt = hub.pull("hwchase17/react")

            # create the model
        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

        agent = create_react_agent(llm=llm, tools=tools, prompt=prompt)
        
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True,handle_parsing_errors=True,return_intermediate_steps=True, max_iterations=20)
        # Create the agent using the new method
       

        return agent_executor, tools