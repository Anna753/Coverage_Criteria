import warnings
warnings.simplefilter("ignore", DeprecationWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

from langchain.agents import Tool, AgentExecutor, create_react_agent
from banking_tools import credit_card_advice, investment_banking_advice
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from banking_tools import credit_card_advice, investment_banking_advice
import getpass
import os

class Agent():
        def __init__():
            pass

        def build_agent():

            def build_tools():
              my_banking_tools = [
                Tool(
                    name="Choose CreditCard",
                    func=credit_card_advice,
                    description="Recommends a credit card from our bank. Input: spending habits, travel frequency, preferred rewards",
                ),
                Tool(
                    name="Investment banking advisor",
                    func=investment_banking_advice,
                    description="Helps you with right kind of recommendations for investment banking",
                ),
              ]
              return my_banking_tools
            
            llm = ChatOpenAI(
                model="google/gemma-3-12b-it",
                base_url="https://openrouter.ai/api/v1",
                temperature=0,api_key=os.environ["OPENROUTER_API_KEY"]
            )
           
            tools = build_tools()
            prompt = PromptTemplate.from_template("""
              You are a helpful financial assistant. Answer the following questions as best you can. You have access to the following tools.

              {tools}

              Use the following format:

              Question: the input question you must answer
              Thought: think about what to do
              Action: the action to take, should be one of [{tool_names}]
              Action Input: the input to the action
              Observation: the result of the action
              ... (this Thought/Action/Action Input/Observation can repeat N times)
              Thought: I now know the final answer
              Final Answer: the final answer to the original question

              Begin!
              
              Question: {input}
              {agent_scratchpad}
              """)
              # Create the ReAct agent
            agent = create_react_agent(llm=llm, tools=tools, prompt=prompt)
            
            agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True, return_intermediate_steps=True,  max_iterations=20)
            return agent_executor, tools