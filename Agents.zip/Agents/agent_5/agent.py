
from langchain_openai import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain_core.tools import Tool
from langchain.agents import (
    create_react_agent,
    AgentExecutor,
)
from langchain import hub
from tools import get_profile_url_tavily
import os
import getpass

class Agent():
    def __init__():
        pass
    def build_agent():
          
        llm = ChatOpenAI(
            temperature=0,
            model_name="gpt-3.5-turbo",
        )
        
        tools_for_agent = [
            Tool(
                name="Crawl Google 4 Twitter profile page",
                func=get_profile_url_tavily,
                description="useful for when you need get the Twitter Page URL",
            )
        ]

        react_prompt = hub.pull("hwchase17/react")
        agent = create_react_agent(llm=llm, tools=tools_for_agent, prompt=react_prompt)
        
        agent_executor = AgentExecutor(agent=agent, tools=tools_for_agent, verbose=True, handle_parsing_errors=True, return_intermediate_steps=True, max_iterations =20)
    

            
        return agent_executor, tools_for_agent