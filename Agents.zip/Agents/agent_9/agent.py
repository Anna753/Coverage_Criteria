from langchain.agents import load_tools
from langchain_openai import ChatOpenAI
from langchain.agents import initialize_agent,AgentType
import os

class Agent():
    def __init__():
        pass
    def build_agent():

      

        llm = ChatOpenAI(
            model="mistralai/mistral-saba",
            base_url="https://openrouter.ai/api/v1",
            temperature=0,api_key=os.environ["OPENROUTER_API_KEY"]
        )
       
        tools = load_tools(["llm-math", "wikipedia", "serpapi"], llm=llm)
        # Create the agent using the new method
        agent = initialize_agent(
            tools=tools,
            llm=llm,
            agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True,
            handle_parsing_errors=True,
            return_intermediate_steps=True, max_iterations=20
        )

        return agent, tools