from langchain.agents import load_tools
from langchain.agents import create_react_agent
from langchain_community.llms import OpenAI
from langchain_openai import OpenAI
from langchain import hub
from langchain.agents import AgentExecutor
from calculator import calculate
import os

class Agent():
    def __init__():
        pass
    def build_agent():

      

        llm = OpenAI(temperature=0)
        tool_names = ["wikipedia", "open-meteo-api"]
        tools = load_tools(tool_names=tool_names, llm=llm)  # the community tools
        tools.extend([calculate])  # a custom tool

        prompt = hub.pull("hwchase17/react")


        agent = create_react_agent(tools=tools, llm=llm, prompt=prompt)
       

        # AgentExecutor with error handling for parsing errors
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True, return_intermediate_steps=True, max_iterations=20)
       

        return agent_executor, tools