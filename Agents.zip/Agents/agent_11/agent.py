from langchain.agents import load_tools
from langchain.agents import initialize_agent
from langchain_openai import OpenAI

class Agent():
    def __init__():
        pass

    def build_agent():

        llm = OpenAI(temperature=0)
        tools = load_tools(["serpapi", "llm-math","wikipedia"], llm=llm)

        
        agent = initialize_agent(tools, llm, agent="zero-shot-react-description",verbose=True,  handle_parsing_errors=True,
            return_intermediate_steps=True,  max_iterations=20)
       
        return agent, tools