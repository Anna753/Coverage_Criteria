from langchain.agents import load_tools
from langchain.agents import initialize_agent
from langchain.agents import AgentType
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import OpenAI, ChatOpenAI
import os
import getpass
from langchain_core.prompts import PromptTemplate
from langchain import hub

class Agent():
    def __init__():
        pass

    def build_agent():


        llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo")

        tools = load_tools(["serpapi", "llm-math"], llm=llm)
        agent_executor = initialize_agent(
            tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True, handle_parsing_errors=True,
    return_intermediate_steps=True,  max_iterations=20
            )
        

        return agent_executor, tools