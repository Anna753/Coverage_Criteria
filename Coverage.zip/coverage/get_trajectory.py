import json
import ast


def safe_parse_tool_input(tool_input):
   
    if isinstance(tool_input, dict):
        return tool_input

    if isinstance(tool_input, str):
        try:
            return json.loads(tool_input)
        except Exception:
            pass

        try:
            return ast.literal_eval(tool_input)
        except Exception:
            pass

        return {"input": tool_input}

    return {"input": str(tool_input)}


def extract_thought_from_log(log):
   
    if not log:
        return ""

    if "Action:" in log:
        return log.split("Action:")[0].strip()

    return log.strip()


def build_dialogs_from_result(query, result):
  
    dialogs = [
        {
            "role": "user",
            "content": query,
        }
    ]

    intermediate_steps = result.get("intermediate_steps", [])

    for action, observation in intermediate_steps:
        tool_name = getattr(action, "tool", None)
        tool_input = getattr(action, "tool_input", None)
        log = getattr(action, "log", "")

        thought = extract_thought_from_log(log)
        arguments = safe_parse_tool_input(tool_input)

        dialogs.append(
            {
                "role": "assistant",
                "tool_calls": [
                    {
                        "type": "function",
                        "function": {
                            "name": tool_name,
                            "arguments": arguments,
                        },
                    }
                ],
                "thought": thought,
            }
        )

        dialogs.append(
            {
                "role": "tool",
                "name": tool_name,
                "content": {
                    "type": "text",
                    "content": str(observation),
                },
            }
        )

    output = result.get("output")
    error = result.get("error")

    if error is not None and output is None:
        dialogs.append(
            {
                "role": "assistant",
                "content": None,
                "error": error,
            }
        )
    else:
        dialogs.append(
            {
                "role": "assistant",
                "content": output if output is not None else "",
            }
        )

    return dialogs