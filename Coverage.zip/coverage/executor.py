from trace_collector import TraceCollector
from get_trajectory import build_dialogs_from_result


class Executor:
    def __init__(self, agent_executor, input_file_path):
        self.agent_executor = agent_executor
        self.input_file_path = input_file_path

    def _is_agent_stopped(self, final_answer):
        if not isinstance(final_answer, str):
            return False

        msg = final_answer.lower()

        stop_patterns = [
            "agent stopped due to iteration limit",
            "iteration limit",
            "time limit",
            "max iterations",
            "stopped due to max iterations",
        ]

        return any(pattern in msg for pattern in stop_patterns)

    def execute(self):
        with open(self.input_file_path, "r") as f:
            test_inputs = [line.strip() for line in f if line.strip()]

        successful_results = []
        crashed_results = []
        stopped_results = []

        for idx, user_input in enumerate(test_inputs):
            print("Running test:", idx + 1)
            print("Query:", user_input)

            collector = TraceCollector()

            try:
                response = self.agent_executor.invoke(
                    {"input": user_input},
                    config={"callbacks": [collector]},
                )

                intermediate_steps = response.get("intermediate_steps", collector.steps)
                if not intermediate_steps:
                    intermediate_steps = collector.steps

                final_answer = response.get("output")
                stopped_by_limit = self._is_agent_stopped(final_answer)

                response["intermediate_steps"] = intermediate_steps
                response["error"] = None

                dialogs = build_dialogs_from_result(user_input, response)

                record = {
                    "query": user_input,
                    "response": response,
                    "output": final_answer,
                    "intermediate_steps": intermediate_steps,
                    "crashed_hard": False,
                    "stopped_by_iteration_limit": stopped_by_limit,
                    "error": None,
                    "dialogs": dialogs,
                }

                if stopped_by_limit:
                    stopped_results.append(record)
                else:
                    successful_results.append(record)

            except Exception as e:
                intermediate_steps = collector.steps
                final_answer = None
                error_msg = str(e)

                response = {
                    "output": None,
                    "intermediate_steps": intermediate_steps,
                    "error": error_msg,
                }

                dialogs = build_dialogs_from_result(user_input, response)

                record = {
                    "query": user_input,
                    "response": response,
                    "output": final_answer,
                    "intermediate_steps": intermediate_steps,
                    "crashed_hard": True,
                    "stopped_by_iteration_limit": False,
                    "error": error_msg,
                    "dialogs": dialogs,
                }

                crashed_results.append(record)

        total = (
            len(successful_results)
            + len(stopped_results)
            + len(crashed_results)
        )

        return {
            "successful": successful_results,
            "stopped": stopped_results,
            "crashed": crashed_results,
            "summary": {
                "total": total,
                "successful": len(successful_results),
                "stopped": len(stopped_results),
                "crashed": len(crashed_results),
            },
        }