from coverage_evaluator import AgentCoverageEvaluator
from executor import Executor
from agent import Agent
import json

agent_executor,declared_tools = Agent.build_agent()

path = "../test_inputs.txt"
exe = Executor(agent_executor,path)
results  = exe.execute()
successful_results = results["successful"]
crashed_results = results["crashed"]
stopped_results = results["stopped"]

completed_trajectories = [
    {
        "dialogs": record["dialogs"],
    }
    for record in successful_results
]

stopped_trajectories = [
    {
        "dialogs": record["dialogs"],
    }
    for record in stopped_results
]

crashed_trajectories = [
    {
        "dialogs": record["dialogs"],
    }
    for record in crashed_results
]

incomplete_trajectories = stopped_trajectories + crashed_trajectories

with open("../complete_trajectories.json", "w", encoding="utf-8") as f:
    json.dump(completed_trajectories, f, indent=2, ensure_ascii=False, default=str)

with open("../incomplete_trajectories.json", "w", encoding="utf-8") as f:
    json.dump(incomplete_trajectories, f, indent=2, ensure_ascii=False, default=str)

declared_tool_names = [
    tool.name if hasattr(tool, "name") else str(tool)
    for tool in declared_tools
]
    

evaluator = AgentCoverageEvaluator(
    traces=successful_results,
    k=10,
    tool_names=declared_tool_names,
)

cov = evaluator.run()

coverage_lines = []

def log_line(text=""):
    print(text)
    coverage_lines.append(str(text))

total_instances = len(successful_results) + len(crashed_results)

log_line("---------------*****----------------")
log_line("Coverage report summary")
log_line(f"Total input instances: {total_instances}")
log_line(f"Total number of completed executions used for coverage: {len(successful_results)}")
log_line(f"Total number of crashed/stopped executions excluded from coverage: {len(crashed_results)+len(stopped_results)}")

log_line("---------------*****----------------")
covered_terms, missing_terms = cov.terminal_cov
log_line(f"Terminal Coverage: {len(covered_terms)}/{len(covered_terms | missing_terms)}")
log_line(f"Covered terminals: {covered_terms}")
log_line(f"Missing terminals: {missing_terms}")


log_line("---------------*****----------------")
covered_prods, missing_prods = cov.production_cov
log_line(f"Production Coverage: {len(covered_prods)}/{len(covered_prods | missing_prods)}")
log_line(f"Covered productions: {covered_prods}")
log_line(f"Missing productions: {missing_prods}")

log_line("---------------*****----------------")
covered_prods_k, missing_prods_k = cov.production_cov_k
log_line(f"Production-(k) Coverage: {len(covered_prods_k)}/{len(covered_prods_k | missing_prods_k)}")
log_line(f"Covered productions upto k: {covered_prods_k}")
log_line(f"Missing productions upto k: {missing_prods_k}")

# log_line("---------------*****----------------")
# depth_cov_k, covered_depth_k, missing_depth_k = cov.production_class_coverage
# # log_line(f"Production-Class coverage: {depth_cov_k:.2f}%")
# log_line(f"Production-Class coverage: {len(covered_depth_k)}/{len(covered_depth_k | missing_depth_k)}")
# log_line(f"Covered class: {covered_depth_k}")
# log_line(f"Missing class: {missing_depth_k}")

# log_line("---------------*****----------------")
# tool_depth_cov = cov.tool_aware_class_coverage
# covered_count = sum(
#     len(covered_depths)
#     for covered_depths in tool_depth_cov["covered_by_tool"].values()
# )

# all_tools = (
#     set(tool_depth_cov["covered_by_tool"].keys())
#     | set(tool_depth_cov["missing_by_tool"].keys())
# )

# total_obligations = (
#     len(tool_depth_cov["required_buckets"])
#     * len(all_tools)
# )
# log_line(
#     f"Tool-aware production-class coverage: "
#     f"{covered_count}/{total_obligations}"
# )
# log_line(f"Declared class: {tool_depth_cov['required_buckets']}")

# log_line("Covered class by tool:")
# for tool, covered_depths in tool_depth_cov["covered_by_tool"].items():
#     log_line(f"  {tool}: {covered_depths}")

# log_line("Missing class by tool:")
# for tool, missing_depths in tool_depth_cov["missing_by_tool"].items():
#     log_line(f"  {tool}: {missing_depths}")

# if tool_depth_cov.get("hallucinated_tools_by_depth"):
#     log_line("Hallucinated tools by depth:")
#     for tool, depths in tool_depth_cov["hallucinated_tools_by_depth"].items():
#         log_line(f"  {tool}: {depths}")


log_line("---------------*****----------------")
tool_result = cov.tool_subtree_cov
log_line(f"Tool co-occurance Coverage: {len(tool_result['covered_patterns'])}/{len(tool_result['covered_patterns'] | tool_result['missing_patterns'])}")
log_line(f"Declared tool set: {tool_result['declared_tool_set']}")
log_line(f"Observed tool set: {tool_result['observed_tool_set']}")
log_line(f"Hallucinated tools: {tool_result['hallucinated_tools']}")
log_line(f"Missing tools: {tool_result['missing_tools']}")
log_line(f"Covered patterns: {tool_result['covered_patterns']}")
log_line(f"Missing patterns: {tool_result['missing_patterns']}")
log_line(f"Hallucinated patterns: {tool_result['hallucinated_patterns']}")

log_line("---------------*****----------------")
tool_depth_result = cov.tool_depth_cov
covered_pairs, missing_pairs, covered_by_tool, missing_by_tool = tool_depth_result
covered_count = len(covered_pairs)
total_count = len(covered_pairs) + len(missing_pairs)

log_line(f"Tool Coverage across Reasoning Lengths: {covered_count}/{total_count}")

all_tools = {
    tool
    for tool, _ in covered_pairs | missing_pairs
}

covered_by_tool = {
    tool: {
        depth
        for t, depth in covered_pairs
        if t == tool
    }
    for tool in all_tools
}

missing_by_tool = {
    tool: {
        depth
        for t, depth in missing_pairs
        if t == tool
    }
    for tool in all_tools
}

log_line("Covered reasoning lengths by tool:")
for tool in sorted(all_tools):
    log_line(f"  {tool}: {covered_by_tool[tool]}")

log_line("Missed reasoning lengths by tool:")
for tool in sorted(all_tools):
    log_line(f"  {tool}: {missing_by_tool[tool]}")

with open("../coverage_results.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(coverage_lines))

print("Saved coverage results to:", "../coverage_results.txt")