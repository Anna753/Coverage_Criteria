from typing import List, Dict, Any
class TraceNormalization:

    def __init__(self,user_input,final_answer,intermediate_steps):
          self.user_input = user_input.strip()
          self.final_answer = (final_answer or "").strip()
          self.intermediate_steps = list(intermediate_steps or [])

    def normalize(self) -> List[Dict[str, Any]]:
        normalized = []
        if self.user_input:
                  normalized.append({"type":"query"})

        for i, (action, observation) in enumerate(self.intermediate_steps):
                thoughts = action.log.split("Action:")[0].strip()
                if thoughts:
                  normalized.append({"type":"thought"})
                if action.tool:
                  normalized.append({"type":"ToolCall","name":action.tool})
                if observation:
                  normalized.append({"type":"obs"})

        if not self.final_answer:
                normalized.append({"type":"crash"})
        elif "agent stopped" in self.final_answer.lower():
                normalized.append({"type":"stop"})
        elif 'agent stopped' not in self.final_answer.lower():
                normalized.append({"type":"answer"})

        return normalized
