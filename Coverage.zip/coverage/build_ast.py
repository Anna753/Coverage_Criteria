from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class ToolCall:
    name: str


@dataclass
class Plan:
    tool_call: ToolCall
    missing_thought: bool = False
    missing_obs: bool = False


@dataclass
class Output:
    kind: str


@dataclass
class TraceAST:
    plans: List[Plan]
    output: Output


class TraceParser:

    OUTPUT_TYPES = {"answer", "stop", "crash"}
    PLAN_START_TYPES = {"thought", "ToolCall"}

    def __init__(self, tokens: List[Dict[str, Any]]):
        self.tokens = tokens
        self.pos = 0

    def _peek(self) -> Optional[Dict[str, Any]]:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def _peek_type(self) -> Optional[str]:
        tok = self._peek()
        return tok.get("type") if tok is not None else None

    def _consume(self, expected_type: str) -> Dict[str, Any]:
        token = self._peek()
        if token is None:
            raise ValueError(
                f"Expected token '{expected_type}', but reached end of trace."
            )

        ttype = token.get("type")
        if ttype != expected_type:
            raise ValueError(
                f"Expected token type '{expected_type}', got '{ttype}' at position {self.pos}."
            )

        self.pos += 1
        return token

    def _at_end(self) -> bool:
        return self.pos >= len(self.tokens)

    def parse_trace(self) -> TraceAST:
        self._consume("query")

        next_type = self._peek_type()

        if next_type is None:
            raise ValueError("Trace ended after 'query' with no output token.")

        if next_type in self.OUTPUT_TYPES and self.pos + 1 == len(self.tokens):
            output = self.parse_output()
            return TraceAST(plans=[], output=output)

        plans = self.parse_planseq()
        output = self.parse_output()

        if not self._at_end():
            raise ValueError(
                f"Extra tokens remaining after parsing Trace at position {self.pos}: "
                f"{self.tokens[self.pos:]}"
            )

        return TraceAST(plans=plans, output=output)

    def parse_planseq(self) -> List[Plan]:
        plans: List[Plan] = []

        while True:
            next_type = self._peek_type()

            if next_type is None:
                break

            if next_type in self.OUTPUT_TYPES:
                break

            if next_type not in self.PLAN_START_TYPES:
                raise ValueError(
                    f"Expected Plan start token ('thought' or 'ToolCall'), "
                    f"got '{next_type}' at position {self.pos}."
                )

            plans.append(self.parse_plan())

        if not plans:
            raise ValueError("Expected at least one Plan in PlanSeq, but found none.")

        return plans

    def parse_plan(self) -> Plan:
       
        missing_thought = False

        if self._peek_type() == "thought":
            self._consume("thought")
        else:
            missing_thought = True

        tool_token = self._consume("ToolCall")
        tool_name = tool_token.get("name")

        if tool_name is None:
            raise ValueError("ToolCall token is missing 'name' field.")

        tool_call = ToolCall(name=tool_name)

        if self._peek_type() == "obs":
            self._consume("obs")
            return Plan(
                tool_call=tool_call,
                missing_thought=missing_thought,
                missing_obs=False,
            )

        return Plan(
            tool_call=tool_call,
            missing_thought=missing_thought,
            missing_obs=True,
        )

    def parse_output(self) -> Output:
        tok = self._peek()

        if tok is None:
            raise ValueError("Expected an Output token, but reached end of trace.")

        ttype = tok.get("type")

        if ttype not in self.OUTPUT_TYPES:
            raise ValueError(
                f"Expected Output token ('answer', 'stop', or 'crash'), "
                f"got '{ttype}' at position {self.pos}."
            )

        self.pos += 1
        return Output(kind=ttype)