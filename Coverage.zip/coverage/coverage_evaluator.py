from dataclasses import dataclass
from typing import List, Set, Tuple, Dict, Any
from itertools import combinations

from trace_normalization import TraceNormalization
from build_ast import TraceParser, TraceAST


ToolName = str
ToolPattern = Tuple[ToolName, ...]


@dataclass
class CoverageResult:
    terminal_cov: Tuple[Set[str], Set[str]]
    production_cov: Tuple[Set[str], Set[str]]
    production_cov_k: Tuple[Set[int], Set[int]]
    tool_subtree_cov: Dict[str, Any]
    tool_depth_cov: Tuple[
        Set[Tuple[str, int]],
        Set[Tuple[str, int]],
        Dict[str, Set[int]],
        Dict[str, Set[int]],
    ]

class AgentCoverageEvaluator:

    BASE_TERMINALS: Set[str] = {
        "query",
        "thought",
        "obs",
        "answer",
    }

    ALL_PRODUCTIONS: Set[str] = {
        "Trace_query_answer",
        "Trace_query_PlanSeq_Output",
        "PlanSeq_Plan",
        "PlanSeq_Plan_PlanSeq",
        "Plan_thought_ToolCall_obs",
        "ToolCall_ToolName",
        "Output_answer",
    }

    def __init__(
        self,
        traces: List[Dict[str, Any]],
        k: int,
        tool_names: List[str],
       
    ):
        self.traces = traces
        self.k = k
        self.all_ast = []
        self.tool_names = tool_names

        self.tool_terminals: Set[ToolName] = {
            str(t).strip() for t in tool_names if str(t).strip()
        }

     

    def run(self) -> CoverageResult:
        for t in self.traces:
            query = t.get("query")
            output = t.get("output")
            intermediate_steps = t.get("intermediate_steps")

            trace_norm = TraceNormalization(query, output, intermediate_steps)
            norm_trace = trace_norm.normalize()

            # print("Normalized Trace:", norm_trace)

            try:
                parser = TraceParser(norm_trace)
                ast = parser.parse_trace()

                if ast.output.kind == "answer":
                    self.all_ast.append(ast)
                   
                else:
                    
                    print(
                        f"Skipping trace for coverage because output is "
                        f"{ast.output.kind!r}: {query!r}"
                    )

            except Exception as e:
                print(f"Failed to parse trace for query {query!r}: {e}")

        if not self.all_ast:
            return CoverageResult(
                terminal_cov=(set(), set()),
                production_cov=(set(), set()),
                production_cov_k=(set(), set()),
                tool_depth_cov={
                    "covered_pairs": set(),
                    "missing_pairs": set(),
                    "covered_by_tool": {},
                    "missing_by_tool": {},
                },
              
                tool_subtree_cov={
                        "declared_tool_set": set(self.tool_names),
                        "observed_tool_set": set(),
                        "hallucinated_tools": set(),
                        "missing_tools": set(self.tool_names),
                        "covered_patterns": set(),
                        "missing_patterns": set(),
                        "hallucinated_patterns": set(),
                    },
               
            )

        terminal_cov = self._terminal_coverage(self.all_ast)
        production_cov = self._production_coverage(self.all_ast)
        production_cov_k = self._production_depth_coverage_up_to_k(self.all_ast)
        tool_subtree_cov = self._tool_subtree_coverage(
            ast_list=self.all_ast,
            declared_tool_names=self.tool_names,
        )
        tool_depth_cov = self._tool_depth_coverage_up_to_k(
            self.all_ast,
            self.tool_names
        )

        return CoverageResult(
            terminal_cov=terminal_cov,
            production_cov=production_cov,
            production_cov_k=production_cov_k,
            tool_subtree_cov=tool_subtree_cov,
            tool_depth_cov=tool_depth_cov
        )

  
    def _normalize_tool_name(self, tool_name: ToolName) -> ToolName:
       
        if tool_name is None:
            return ""

        tool_name = str(tool_name).strip()

        if "Action:" in tool_name:
            tool_name = tool_name.split("Action:")[-1].strip()
            tool_name = tool_name.split("\n")[0].strip()

        return tool_name

    def _is_valid_tool_name(self, tool_name: ToolName) -> bool:
       
        if tool_name is None:
            return False

        tool_name = self._normalize_tool_name(tool_name)

        if not tool_name:
            return False

        if tool_name in {"_Exception", "Exception"}:
            return False

        return True


    def _terminals_in_ast(self, ast: TraceAST) -> Set[str]:
        terms: Set[str] = set()

        terms.add("query")

        if ast.plans:
            terms.add("thought")
            terms.add("obs")

        for plan in ast.plans:
            if plan.tool_call and plan.tool_call.name:
                name = self._normalize_tool_name(plan.tool_call.name)

                if name in self.tool_terminals:
                    terms.add(name)

        terms.add(ast.output.kind)

        return terms

    def _terminal_coverage(
        self,
        ast_list: List[TraceAST],
    ) -> Tuple[float, Set[str], Set[str]]:
        sigma: Set[str] = self.BASE_TERMINALS | self.tool_terminals

        covered: Set[str] = set()

        for ast in ast_list:
            covered |= self._terminals_in_ast(ast)

        covered_in_sigma = covered & sigma
        missing_in_sigma = sigma - covered_in_sigma

        return covered_in_sigma, missing_in_sigma


    def _productions_covered_by_ast(self, ast: TraceAST) -> Set[str]:
        covered: Set[str] = set()

        if len(ast.plans) == 0 and ast.output.kind == "answer":
            covered.add("Trace_query_answer")

        if len(ast.plans) >= 1:
            covered.add("Trace_query_PlanSeq_Output")

        if len(ast.plans) == 1:
            covered.add("PlanSeq_Plan")

        if len(ast.plans) >= 2:
            covered.add("PlanSeq_Plan_PlanSeq")

        if ast.plans:
            covered.add("Plan_thought_ToolCall_obs")

        if any(plan.tool_call is not None for plan in ast.plans):
            covered.add("ToolCall_ToolName")

        if ast.output.kind == "answer":
            covered.add("Output_answer")
        elif ast.output.kind == "stop":
            covered.add("Output_stop")
        elif ast.output.kind == "crash":
            covered.add("Output_crash")
        else:
            raise ValueError(f"Unknown output kind: {ast.output.kind}")

        return covered

    def _production_coverage(
        self,
        ast_list: List[TraceAST],
    ) -> Tuple[float, Set[str], Set[str]]:
        p: Set[str] = self.ALL_PRODUCTIONS

        if not p:
            return 100.0, set(), set()

        covered: Set[str] = set()

        for ast in ast_list:
            covered |= self._productions_covered_by_ast(ast)

        covered_in_p = covered & p
        missing_in_p = p - covered_in_p

        return covered_in_p, missing_in_p


    def _production_depth_coverage_up_to_k(
        self,
        ast_list: List[TraceAST],
    ) -> Tuple[float, Set[int], Set[int]]:
       
        if self.k <= 0:
            raise ValueError("k must be >= 1")

        required_depths: Set[int] = set(range(2, self.k + 1))
        covered_depths: Set[int] = set()

        for ast in ast_list:
            d = len(ast.plans)

            if 2 <= d <= self.k:
                covered_depths.add(d)

        missing_depths = required_depths - covered_depths
    
        return  covered_depths, missing_depths

    def _extract_tool_sequence_from_ast(
        self,
        ast: TraceAST,
    ) -> List[ToolName]:
       
        sequence: List[ToolName] = []

        for plan in ast.plans:
            if plan.tool_call and plan.tool_call.name:
                name = self._normalize_tool_name(plan.tool_call.name)

                if self._is_valid_tool_name(name):
                    sequence.append(name)

        return sequence


    def _extract_observed_tools_and_traces_from_asts(
        self,
        ast_list: List[TraceAST],
    ) -> Tuple[Set[ToolName], List[List[ToolName]]]:
       
        observed_tool_set: Set[ToolName] = set()
        observed_tool_traces: List[List[ToolName]] = []

        for ast in ast_list:
            seq = self._extract_tool_sequence_from_ast(ast)

            clean_seq = [
                self._normalize_tool_name(tool)
                for tool in seq
                if self._is_valid_tool_name(tool)
            ]

            observed_tool_traces.append(clean_seq)
            observed_tool_set.update(clean_seq)

        return observed_tool_set, observed_tool_traces


    def _canonical_cooccurrence_pattern(
        self,
        pat: ToolPattern,
    ) -> ToolPattern:
       
        return tuple(sorted(pat))


    def _generate_feasible_patterns(
        self,
        declared_tool_set: Set[ToolName],
    ) -> Set[ToolPattern]:
       
        feasible_patterns: Set[ToolPattern] = set()

        declared_tool_set = {
            self._normalize_tool_name(tool)
            for tool in declared_tool_set
            if self._is_valid_tool_name(tool)
        }

        tools = sorted(declared_tool_set)
        num_tools = len(tools)

        for tool in tools:
            feasible_patterns.add(
                self._canonical_cooccurrence_pattern((tool, tool))
            )

        for pattern_len in range(2, num_tools + 1):
            for pat in combinations(tools, pattern_len):
                feasible_patterns.add(
                    self._canonical_cooccurrence_pattern(pat)
                )

        return feasible_patterns


    def _extract_observed_patterns_from_tool_traces(
        self,
        observed_tool_traces: List[List[ToolName]],
    ) -> Set[ToolPattern]:
 
        observed_patterns: Set[ToolPattern] = set()

        for trace in observed_tool_traces:

            clean_trace = [
                self._normalize_tool_name(tool)
                for tool in trace
                if self._is_valid_tool_name(tool)
            ]

    
            if len(clean_trace) < 2:
                continue

            unique_tools = set(clean_trace)

            if not unique_tools:
                continue

            if len(unique_tools) == 1:
                tool = next(iter(unique_tools))
                pattern = (tool, tool)

            else:
             
                pattern = tuple(unique_tools)

            observed_patterns.add(
                self._canonical_cooccurrence_pattern(pattern)
            )

        return observed_patterns


    def _tool_subtree_coverage(
        self,
        ast_list: List[TraceAST],
        declared_tool_names: List[str],
    ) -> Dict[str, Any]:
       

        declared_tool_set: Set[ToolName] = {
            self._normalize_tool_name(tool)
            for tool in declared_tool_names
            if self._is_valid_tool_name(tool)
        }

        observed_tool_set, observed_tool_traces = (
            self._extract_observed_tools_and_traces_from_asts(ast_list)
        )

        feasible_patterns = self._generate_feasible_patterns(
            declared_tool_set
        )

        observed_patterns = (
            self._extract_observed_patterns_from_tool_traces(
                observed_tool_traces
            )
        )

        covered_patterns = observed_patterns & feasible_patterns
        missing_patterns = feasible_patterns - covered_patterns
        hallucinated_patterns = observed_patterns - feasible_patterns

        hallucinated_tools = observed_tool_set - declared_tool_set
        missing_tools = declared_tool_set - observed_tool_set


        return {
          
            "declared_tool_set": declared_tool_set,
            "observed_tool_set": observed_tool_set,
            "hallucinated_tools": hallucinated_tools,
            "missing_tools": missing_tools,
            "feasible_patterns": feasible_patterns,
            "observed_patterns": observed_patterns,
            "covered_patterns": covered_patterns,
            "missing_patterns": missing_patterns,
            "hallucinated_patterns": hallucinated_patterns,
        }

    
    def _tool_depth_coverage_up_to_k(
            self,
            ast_list: List[TraceAST],
            all_tools: Set[str],
        ):
            if self.k <= 0:
                raise ValueError("k must be >= 1")

            required_pairs = {
                (tool, depth)
                for tool in all_tools
                for depth in range(1, self.k + 1)
            }

            covered_pairs = set()

            for ast in ast_list:
                depth = len(ast.plans)

                if not (1 <= depth <= self.k):
                    continue

                tools_used = {
                self._normalize_tool_name(plan.tool_call.name)
                for plan in ast.plans
                if plan.tool_call is not None
                and self._is_valid_tool_name(plan.tool_call.name)
            }

                for tool in tools_used:
                    if tool in all_tools:
                        covered_pairs.add((tool, depth))

            missing_pairs = required_pairs - covered_pairs

            covered_by_tool = {
                tool: {
                    depth
                    for t, depth in covered_pairs
                    if t == tool
                }
                for tool in all_tools
            }

            missing_by_tool = {
                tool: {
                    depth
                    for t, depth in missing_pairs
                    if t == tool
                }
                for tool in all_tools
            }

            return covered_pairs, missing_pairs, covered_by_tool, missing_by_tool