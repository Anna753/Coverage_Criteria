from typing import List, Tuple, Any
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.agents import AgentAction


class TraceCollector(BaseCallbackHandler):

    def __init__(self) -> None:
        self.steps: List[Tuple[Any, Any]] = []
        self._last_action: Any = None

    def on_agent_action(self, action: AgentAction, **kwargs: Any) -> Any:
        self._last_action = action


    def on_tool_end(self, output: Any, **kwargs: Any) -> Any:
        if self._last_action is not None:
            self.steps.append((self._last_action, output))
            self._last_action = None


    def on_tool_error(self, error: Exception, **kwargs: Any) -> Any:
        if self._last_action is not None:
            self.steps.append((self._last_action, f"ERROR: {error}"))
            self._last_action = None

